//**************************************************************************
// Práctica 1
//
// Domingo Martin Perandres 2013
//
// GPL
//**************************************************************************

#include <GL/gl.h>
#include <vector>

using namespace std;

void draw_cube();

void draw_vertices(vector<float> &Vertices);


